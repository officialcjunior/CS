
/*Author:Hrishikesh P
  Roll NO:AM.EN.U4CSE19024
  Class-CSE-A
  This pgm helps us to merge two sorted arrays*/
  
#include<stdio.h>
void MergeArray(int a[],int b[],int n,int m,int c[])
{
	int i=0,j=0,k=0;
	while(i<n && j<m) //Condtion for while loop if any of the i or j vallue
	{                 //equals the size of the corresponding array the loop breaks 
		if(a[i]<b[j])  //If a[i]<b[j] we insert the element of array a to c
		{
			c[k]=a[i++];
		}
		else          //else we insert the element of array b to c
		{
			c[k]=b[j++];
		}
		k++;
	}
	if(i>=n)  //If all the elements of array a is in c then we tranfer the
	{         //remaining elements in array b if any
		while(j<m)
		{
			c[k]=b[j++];
			k++;
		}
	}
	if(j>=m) //If all the elements of array a is in c then we tranfer the
	{         //remaining elements in array b if any
		while(i<n)
		{
			c[k]=a[i++];
			k++;
		}
	}
	printf("The Array after merging:");
	for(i=0;i<n+m;i++)
		printf("%d ",c[i]);
	
}
int main()
{
	int n,m;
	printf("Enter the size of the first array:");
	scanf("%d",&n);  //Reading the size of the first array
	printf("Enter the size of the second array:");
	scanf("%d",&m);  //Reading the size of the second array
	int a[n],b[m];
	printf("Enter the first array:");
	for(int i=0;i<n;i++)
		scanf("%d",&a[i]);   //Reading the first array
	printf("Enter the second array:");
	for(int i=0;i<m;i++)
		scanf("%d",&b[i]); //Reading the second array
	int c[n+m]; //Declaring a array of size n+m
	MergeArray(a,b,n,m,c);  //Function Call
}
