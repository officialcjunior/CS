//T R Hari Subramaniam CSE A AM.EN.U4CSE19056
#include <stdio.h>
#include <string.h>

int main()
{
    
    char str1[100],str2[100],str3[200];
    printf("Enter the string\n");
    scanf("%s",str1);

    strcpy(str2, str1);  //This helps to copy str1 string to the str2 string 
    puts(str2);
    strcat(str1,str2);   //This concatenates the 2nd string to the 1st string
    int l=strlen(str2);  //This helps to find the length
    printf("%d\n",l);
    puts(str1);
    return 0;
}
