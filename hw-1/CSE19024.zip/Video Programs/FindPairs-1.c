/*Author:Hrishikesh P
  Roll NO:AM.EN.U4CSE19024
  Class-CSE-A
  This program helps us to generate unique pairs of required sum*/
#include<stdio.h>
void FindPairs(int a[],int n,int sum)
{
	for(int i=0;i<n;i++)
	{
		for(int j=i+1;j<n;j++) //Generating unique pairs
		{
			if(a[i]+a[j]==sum)
			printf("%d %d\n",a[i],a[j]);	//Printing the pairs with equal sum
		}	
	}	
}
int main()
{
	int n,sum=0;
	printf("Enter the size of the array:"); 
	scanf("%d",&n);  //Reading the size of the array
	int a[n];
	printf("Enter the array:");
	for(int i=0;i<n;i++)
		scanf("%d",&a[i]);  //Readiing the array
	printf("Enter the sum:");
	scanf("%d",&sum);  //Reading thr required sum
	FindPairs(a,n,sum); //Function Call
	return 0;
}
