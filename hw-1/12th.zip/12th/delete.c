/*T R Hari Subramaniam AM.EN.U4CSE19056 CSE A */
#include<stdio.h>  
int delete(int arr[], int size, int value) 
{  
   int i; 
   for (i=0; i<size; i++) 
      if (arr[i] == value)   //If the element is there in the array the loop will break here
         break; 
   if (i < size)             //If the element is there in the array then i will never be equal to the size.........
   { 
     size=size-1; 
     for (int j=i; j<size; j++) 
        arr[j] = arr[j+1]; 
   } 
   printf("Final array after modification\n");
   for(i=0;i<size;i++)
   printf("%d\t",arr[i]);
   printf("\n");
   return size; 
} 
int main() 
{ 
   int n,array[100]={0},x;
   printf("Enter the initial size of the array\n");
   scanf("%d",&n);
   printf("Enter the elements of the array\n");
   for(int i=0;i<n;i++)
   scanf("%d",&array[i]);
   printf("Enter the value to be deleted\n");
   scanf("%d",&x);
   delete(array,n,x); 
   return 0; 
} 
