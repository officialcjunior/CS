/*T R Hari Subramaniam AM.EN.U4CSE19056 CSE A */
#include<stdio.h>
int main() 
{ 
  int x = 10;    //An integer x declared
  int *y, **z;    // An integer pointer y declared. A pointer to a pointer ,z declared
  y = &x;  // Now y points to x
  z = &y;  //z can store address of a pointer. To access content of y using z, use **z
  printf("x = %d, y = %d, z = %d\n", x, *y, **z);  
  
  return 0;   // *z refers to content pointed by z which is y. **z refers to content pointed by y ie10
}
