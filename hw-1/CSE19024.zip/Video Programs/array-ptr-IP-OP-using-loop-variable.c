/*Author:Hrishikesh P
  Roll NO:AM.EN.U4CSE19024
  Class-CSE-A*/
  
#include<stdio.h>
int main()
{
	int x[100];
	for(int i=0;i<5;i++)
	{
		scanf("%d",x+i);
	}
	printf("\nUpdated Array:");
	for(int i=0;i<5;i++)
	printf("%d ",*(x+i));
	return 0;
}