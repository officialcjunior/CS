/*T R Hari Subramaniam AM.EN.U4CSE19056 CSE A */
#include<stdio.h>
int main()
{ 
  int A[5]={1,2,3,4,5}; //Declare and initialise Array
  int *ptr=A+2;// Assign ptr
  for(int i=0;i<5;i++)
  { 
    (*ptr)*=2;    //Computation (*ptr) =(*ptr)*2
    --ptr;
  }
  for(int i=0;i<5;i++)
  printf("%d ",A[i]);
  printf("\n");
 
  return 0;
}
