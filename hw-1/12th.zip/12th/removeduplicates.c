/*T R Hari Subramaniam AM.EN.U4CSE19056 CSE A */
#include<stdio.h>
int duplicateRemoval(int arr[],int size)
{ 
  int i,k,j;
  for(i=0; i<size; i++)
  {
    for(j=i+1; j<size; j++)
    {
      if(arr[i] == arr[j])    /* If any duplicate found */
      {
        /* Delete the current duplicate element */
        for(k=j; k<size; k++)
        {
           arr[k] = arr[k + 1];
        }
        size--; /* Decrement size after removing duplicate element .*/
        j--;        /* If shifting of elements occur then don't increment j */
      }
    }
  }
  for(i=0;i<size;i++)
  printf("%d\t",arr[i]);
  printf("\n");
  return size;
}
int main()
{
  int n;
  printf("Enter the size of the array\n");
  scanf("%d",&n);
  int arr[n];
  printf("Enter the values of the array\n");
  for(int i=0;i<n;i++)
  scanf("%d",&arr[i]);
  duplicateRemoval(arr,n);
  
  return 0;
}
