/*Author:Hrishikesh P
  Roll NO:AM.EN.U4CSE19024
  Class-CSE-A*/
  
#include<stdio.h>
int main()
{
	int x=10;
	int *y,**z;
	y=&x;
  	z=&y;
	printf("x=%d y=%d z=%d",x,*y,**z);
	return 0;
}