/*T R Hari Subramaniam AM.EN.U4CSE19056 CSE A */
#include<stdio.h>
int main()
{
  int var1;
  printf("Address of var1 variable : %p\n", &var1);
  return 0;
}
