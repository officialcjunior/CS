//T R Hari Subramaniam CSE A AM.EN.U4CSE19056
#include<stdio.h>
#include<string.h>
int main()
{
  char c[100];
  printf("Enter the binary string:\n");
  scanf("%s",c);
  int i,l=strlen(c),t=0;
  for(i=0;i<l;i++)
  {
    if(c[i]=='1')
    t++;
    else
    {
      if(t>0)
      {
        printf("%d\t",t);
        t=0;
      }
    }
  }
  if(t!=0)
  printf("%d\t",t);
  printf("\n");
  return 0;
}
