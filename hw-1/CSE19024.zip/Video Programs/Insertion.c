/*Author:Hrishikesh P
  Roll NO:AM.EN.U4CSE19024
  Class-CSE-A
  This pgm hepls us to insert an element in the array at the required postion*/
  
#include<stdio.h>
int Insertion(int a[],int limit,int e,int pos)
{
	for(int i=limit-1;i>=pos-1;i--) //Shifting the elements to make space for the element
	{
		a[i+1]=a[i];
	}
	a[pos-1]=e; //Assiging the element to the required position
	limit+=1;c  //Updating the limit of the array
	return limit;
}
int main()
{
	const int SIZE=100;
	int a[SIZE],limit,e,pos;
	printf("Enter the limit of n:");
	scanf("%d",&limit); //Reading the limit of the array
	printf("\nEnter the elements:"); 
	for(int i=0;i<limit;i++)
	{
		scanf("%d",&a[i]);  //Reading the array elements
	}
	printf("\nEnter the element to be inserted:");
	scanf("%d",&e); //Reading the element to be inserted
	printf("Enter the position:");
	scanf("%d",&pos); //Reading the postion of the element where the element has to be inserted
	limit=Insertion(a,limit,e,pos);
	printf("Resultant Array:");  //Printing the updated array
	for(int i=0;i<limit;i++)
		printf("%d ",a[i]);
	return 0;
}
