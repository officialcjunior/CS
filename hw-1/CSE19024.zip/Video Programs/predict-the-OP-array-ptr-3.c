/*Author:Hrishikesh P
  Roll NO:AM.EN.U4CSE19024
  Class-CSE-A*/
  
#include<stdio.h>
int main()
{
	int a[5]={1,2,3,4,5};
	int *ptr=a+2;
	ptr=a;
	for(int i=0;i<5;i++)
	{
		(*ptr)*=2;
		--ptr;
	}
	for(int i=0;i<5;i++)
		printf("%d ",a[i]);
	return 0;
}