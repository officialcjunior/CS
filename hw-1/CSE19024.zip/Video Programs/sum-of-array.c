/*Author:Hrishikesh P
  Roll NO:AM.EN.U4CSE19024
  Class-CSE-A*/
  
#include<stdio.h>
int main()
{
	const int SIZE=100;
	int n,x,sum=0,a[SIZE];
	
	printf("Enter the limit of n:");
	scanf("%d",&n);
	printf("\nEnter the elemets:");
	for(int i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
		sum+=a[i];
	}
	for(int i=0;i<n;i++)
		a[i]+=1;
	printf("\nUpdated Array:");
	for(int i=0;i<n;i++)
		printf("%d ",a[i]);
	printf("\nSum of the elements=%d",sum);
	return 0;
}