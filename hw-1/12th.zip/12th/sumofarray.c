/*T R Hari Subramaniam AM.EN.U4CSE19056 CSE A */
#include<stdio.h>
int main()
{
  const int SIZE=100;
   //Array size is fixed once declared statically.So declaring as const
  int x[SIZE],n,s=0;
  printf("This is the program for adding n numbers.Enter the limit n\n");
  scanf("%d",&n);
  printf("Enter the elements\n");
  //Read the array
  for(int i=0;i<n;i++)
  scanf("%d",&x[i]);
  for(int i=0;i<n;i++)
  s=s+x[i];
  printf("Sum of elements %d\n",s);
  for(int i=0;i<n;i++)
  x[i]=x[i]+1;
  printf("The updated array is : \n");
  for(int i=0;i<n;i++)
  printf("%d ",x[i]);
  printf("\n");
  return 0;
}
