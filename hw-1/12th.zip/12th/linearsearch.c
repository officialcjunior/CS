/*T R Hari Subramaniam AM.EN.U4CSE19056 CSE A */
#include <stdio.h>
void search(int [],int,int);  // Function prototype
int main()
{ 
  const int SIZE=100;
  int A[SIZE],n,i,element;
  printf("This is the program for searching an element in an array\n");
  printf("Enter the limit\n");
  scanf("%d",&n);
  printf("Enter the array\n");
  for (i=0;i<n;i++)
  scanf("%d",&A[i]);
  
  printf("Enter the element to be searched\n");
  scanf("%d",&element);
  search(A,n,element);   // Function Call
  
  return 0;
}

void search(int A[],int limit,int element) // Function Definition
{        
  int i;
  for(i=0;i<limit;i++)
  {
    if (A[i]==element)
    {   
      printf("Found %d at index %d\n",element,i);
      break;
    }
  }
  if(i==limit)
  printf("Element not found");
}
