/*T R Hari Subramaniam AM.EN.U4CSE19056 CSE A */
#include<stdio.h>
int main()
{
   int array[100];
   char name[20];
   float Farray[100];
   double Darray[20];
   printf(" Size of int :%lu bytes\n",sizeof(array));
   printf(" Size of char :%lu bytes\n",sizeof(name));
   printf(" Size of float :%lu bytes\n",sizeof(Farray));
   printf(" Size of double :%lu bytes\n",sizeof(Darray));
   return 0;
}
