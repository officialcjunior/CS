/*Author:Hrishikesh P
  Roll NO:AM.EN.U4CSE19024
  Class-CSE-A
  This pgm hels us to find search for an element in the array*/
  
#include<stdio.h>
void Lsearch(int a[],int limit,int e)
{
	int i;
	for(i=0;i<limit;i++)
	{
		if(a[i]==e) //checking if any of the elements is equal to the required element
		{
			printf("\nFound %d at index %d",e,i);
			break;
		}
	}
	if(i==limit) //If not found 
	printf("\nElement not found");
}
int main()
{
	const int SIZE=100;
	int a[SIZE],limit,e;
	printf("Enter the limit of n:"); //Reading the limit of the array
	scanf("%d",&limit);
	printf("\nEnter the elemets:"); 
	for(int i=0;i<limit;i++)
	{
		scanf("%d",&a[i]);  //Reading the content of the array
	}
	printf("\nEnter the element to be searhed:");
	scanf("%d",&e);  //Reading the element to be searched
	Lsearch(a,limit,e); //Function call
	return 0;
}
