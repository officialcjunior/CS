//T R Hari Subramaniam CSE A AM.EN.U4CSE19056
#include<stdio.h>
#include<string.h>
int main()
{
  char c[100],ch[100];
  printf("Enter the string:\n");
  scanf("%s",c);
  int l=strlen(c),i;
  if(l%2!=0)
  printf("Not possible as string length is odd\n");
  else
  {
    for(i=0;i<l;i+=2)
    {
      ch[i]=c[i+1];
      ch[i+1]=c[i];
    }
    printf("%s\n",ch);
  }
  return 0;
}
