/*Author:Hrishikesh P
  Roll NO:AM.EN.U4CSE19024
  Class-CSE-A*/
  
#include<stdio.h>
int main()
{
	int i=6,*j,k;
	j=&i;
  	printf("%d",i**j*i+*j);
	return 0;
}