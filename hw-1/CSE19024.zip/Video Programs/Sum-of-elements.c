/*Author:Hrishikesh P
  Roll NO:AM.EN.U4CSE19024
  Class-CSE-A*/
  
#include<stdio.h>
int main()
{
	int n,x,sum=0;
	printf("Enter the limit of n:");
	scanf("%d",&n);
	printf("\nEnter the elemets:");
	for(int i=0;i<n;i++)
	{
		scanf("%d",&x);
		sum+=x;
	}
	printf("\nSum of the elements=%d",sum);
	return 0;
}