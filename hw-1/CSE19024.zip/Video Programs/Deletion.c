/*Author:Hrishikesh P
  Roll NO:AM.EN.U4CSE19024
  Class-CSE-A
  Prgram to delete an element at the required positon*/
  
#include<stdio.h>
int Deletion(int a[],int limit,int pos)
{
	for(int i=pos-1;i<limit;i++) 
	{
		a[i]=a[i+1];  //dlelting the element
	}
	limit-=1;  //reducing the size of the array after deletion
	return limit;
}
int main()
{
	const int SIZE=100;
	int a[SIZE],limit,e,pos;
	printf("Enter the limit of n:"); 
	scanf("%d",&limit);   //taking the size of the array
	printf("\nEnter the elements:"); 
	for(int i=0;i<limit;i++)
	{
		scanf("%d",&a[i]);   //inputing the size of the array
	}
	printf("Enter the position:");
	scanf("%d",&pos);  
	limit=Deletion(a,limit,pos);  //Function call
	printf("Resultant Array:");
	for(int i=0;i<limit;i++)
		printf("%d ",a[i]);  //Dispalying the array
	return 0;
}
