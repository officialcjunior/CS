/*T R Hari Subramaniam AM.EN.U4CSE19056 CSE A */
#include <stdio.h> 
int insert(int array[],int limit,int position,int value)
{ 
  for(int i=limit-1;i>=position-1;i--)
  array[i+1]=array[i];
  
  array[position-1]=value;
  limit=limit+1;
  for (int i = 0;i<limit; i++)
  printf("%d\t",array[i]);
  printf("\n");
  printf("Element inserted\n");
  return limit; 
}
int main() 
{ 
    int arr[100] = { 0 }; 
    int i, x, pos,n;
    
    printf("Enter the size of the initial array\n"); 
    scanf("%d",&n);
    printf("Enter the elements of the array\n");
    for (i = 0;i<n; i++) 
    scanf("%d",&arr[i]);
   
    printf("Enter the element to be inserted and the position\n");
    scanf("%d%d",&x,&pos);
    insert(arr,n,pos,x);
  
    return 0; 
} 

