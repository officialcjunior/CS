/*T R Hari Subramaniam AM.EN.U4CSE19056 CSE A */
#include<stdio.h> 
int main()
{ 
   int a = 5;    //integer declared
   int *ptr;    //An integer pointer ptrdeclared
   ptr= &a;    // ptris assigned the address of integer a.ptrnow points to a
   *ptr= *ptr* 3;   //(*ptr): deferencingthe ptrieaccess the content pointed by ptr
   printf("%d\n", a);   //deferencinga ptrmeans access/manipulate the content pointed by ptr
   
   return 0; 
} 
