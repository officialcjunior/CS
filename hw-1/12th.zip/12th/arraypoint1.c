/*T R Hari Subramaniam AM.EN.U4CSE19056 CSE A */
#include<stdio.h>
int main() 
{  
  int a[] = { 1, 2, 3, 4, 5} ; //initialise the array with 5 elements
  int *ptr;         //Declare an integer pointer ptr
  ptr= a;         //Assign the base address of array a[] to ptr. Now ptrpoints to a
  printf(" %d \n", *( ptr+ 1) ); //What is the output?
  return 0; 
} 
