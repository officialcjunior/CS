/*Author:Hrishikesh P
  Roll NO:AM.EN.U4CSE19024
  Class-CSE-A*/
  
#include<stdio.h>
int main()
{
	int a=5;
	int *ptr;
	ptr=&a;
  	*ptr=*ptr*3;
  	printf("%d",a);
	return 0;
}