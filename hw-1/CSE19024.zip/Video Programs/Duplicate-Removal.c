/*Author:Hrishikesh P
  Roll NO:AM.EN.U4CSE19024
  Class-CSE-A
  This program helps us to delete the duplicates in an array*/
  
#include<stdio.h>
void DupRMV(int a[],int n)
{
	for(int i=0;i<n;i++)
	{
		for(int j=i+1;j<n;j++)
		{
			if(a[i]==a[j]) //Checking if there are any elements equal by egenrating pairs
			{
				for(int k=j;k<n;k++)
	            {
		            a[k]=a[k+1]; //deteing the redundant element
	            }
	            n--; //decreasing the size of the array after deletion
				j--; //decrementing the value of j after the deletion
			}
		}	
	}
	printf("\nUpdated Array:");
	for(int i=0;i<n;i++)
	printf("%d ",a[i]);  //printing the updated array
}

int main()
{
	int n;
	printf("Enter the size of the array:");
	scanf("%d",&n);  //Taking the input of the size of the array
	int a[n];
	printf("Enter the array:");
	for(int i=0;i<n;i++)
		scanf("%d",&a[i]); //Taking the input of the array
	DupRMV(a,n); //Function Call
	return 0;
}
