/*Author:Hrishikesh P
  Roll NO:AM.EN.U4CSE19024
  Class-CSE-A*/
  
#include<stdio.h>
int main()
{
	int a[5]={15,20,30,55,70};
	int *ptr;
	ptr=a;
	while(*ptr<30)
	{
		if(*ptr%2!=0)
			*ptr+=2;
		else
			*ptr+=1;
		ptr+=1;
	}
	for(int i=0;i<5;i++)
		printf("%d ",a[i]);
	return 0;
}