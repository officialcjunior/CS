//T R Hari Subramaniam CSE A AM.EN.U4CSE19056
#include<stdio.h>
#include<string.h>
int main()
{
  char c[100];
  printf("Enter the string : \n");
  scanf("%s",c);
  int i,j,f=0;
  for(i=0;i<strlen(c)-1;i++)
  {
     for(j=i+1;j<strlen(c);j++)
     {
        if(c[i]==c[j])
        {
          f=1;
          break;
        }
     }
     if(f==1)
     {
       printf("NO\n");
       break;
     }
  }
  if(f==0)
  printf("YES\n");
  return 0;
}
