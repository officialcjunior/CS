/*T R Hari Subramaniam AM.EN.U4CSE19056 CSE A */
#include<stdio.h>
void FindPair(int arr[],int limit,int S)
{ 
  int i,j;
  for(i=0; i<limit; i++)
  {
    for(j=0; j<limit; j++)
    {
      if(arr[i]+arr[j]==S)
      printf("(%d %d)",arr[i],arr[j]);
    }
  }
  printf("\n");
}
int main()
{
  int n,s;
  printf("Enter the size of the array\n");
  scanf("%d",&n);
  int arr[n];
  printf("Enter the elements of the array\n");
  for(int i=0;i<n;i++)
  scanf("%d",&arr[i]);
  printf("Enter the sum s\n");
  scanf("%d",&s);
  
  FindPair(arr,n,s);
  return 0;

}
