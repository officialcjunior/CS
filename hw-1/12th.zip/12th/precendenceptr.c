/*T R Hari Subramaniam AM.EN.U4CSE19056 CSE A */
#include<stdio.h>
int main() 
{
  int i= 6, *j, k; // Declares an integer i,pointerj, int k
  j = &i;      // Assign address of ito ptrj. Now j points to i
  printf("%d\n", i* *j * i+ *j); // Following precedence rule multiplication happens first
  return 0; 
} 
