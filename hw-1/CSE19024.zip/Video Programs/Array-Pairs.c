/*Author:Hrishikesh P
  Roll NO:AM.EN.U4CSE19024
  Class-CSE-A 
  Program to generate pairs in ana array*/

#include<stdio.h>
void pairs(int a[])
{
	for(int i=0;i<5;i++)
	{
		for(int j=i+1;j<5;j++)
		{
			printf("Array[%d]=%d,Array[%d]=%d\n",i,a[i],j,a[j]); //Printing the pairs	
		}	
	}	
}
int main()
{
	int a[5]={1,2,3,4,5};
	pairs(a);
	return 0;
}
