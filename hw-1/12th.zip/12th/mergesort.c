/*T R Hari Subramaniam AM.EN.U4CSE19056 CSE A */
#include<stdio.h>
void merge(int array1[],int m,int array2[],int n)
{     
  int i=0,j=0,k=0,array3[m+n];
  while (i < m && j < n) 
  {
    if (array1[i] < array2[j]) 
    {
      array3[k] = array1[i++];
    }
    else 
    {
      array3[k] = array2[j++];
    } 
    k++;
  }
  if (i >= m) 
  {
    while (j < n) 
    {
      array3[k] = array2[j];
      j++;
      k++;
    }
  }
  if (j >= n) 
  {
    while (i < m)
    {
       array3[k] = array1[i];
       i++;
       k++;
    }
  }
  printf("The merged array is\n");
  for(i=0;i<m+n;i++)
  printf("%d\t",array3[i]);
  printf("\n");
}// End of merge

int main()
{
  int n,n1,i;
  printf("Enter the size of the 1st array\n");
  scanf("%d",&n);
  int array1[n];
  printf("Enter the elements of the 1st array\n");
  for(i=0;i<n;i++)
  scanf("%d",&array1[i]);
  printf("Enter the size of the 2nd array\n");
  scanf("%d",&n1);
  int array2[n1];
  printf("Enter the elements of the 2nd array\n");
  for(i=0;i<n1;i++)
  scanf("%d",&array2[i]);
  
  
  merge(array1,n,array2,n1);
  return 0;
}  



