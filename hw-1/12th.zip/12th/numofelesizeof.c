/*T R Hari Subramaniam AM.EN.U4CSE19056 CSE A */
#include<stdio.h>
int main()
{
   int array[]={1,2,3,4,5,6,7,8,9,10,11};
   printf(" Number of elements: %lu \n",sizeof(array)/sizeof(array[0]));
   return 0;
}
